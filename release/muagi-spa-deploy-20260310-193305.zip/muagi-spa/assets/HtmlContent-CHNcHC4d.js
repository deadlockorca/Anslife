import{j as e}from"./index-CxW_5pwG.js";function o({html:t,className:n}){return t?e.jsx("article",{className:n??"html-content",dangerouslySetInnerHTML:{__html:t}}):null}export{o as H};
