const h={"about-anslife":`
<div class="ai-content">
  <figure class="ai-banner">
    <img src="/assets/ai/about-anslife.svg" alt="Về ANSLIFE" loading="lazy" decoding="async" />
  </figure>

  <p class="ai-intro">
    ANSLIFE phát triển theo định hướng doanh nghiệp sản xuất nội thất xuất khẩu có năng lực vận hành ổn định,
    linh hoạt theo từng thị trường và cam kết đồng hành dài hạn với đối tác.
  </p>

  <div class="ai-stat-grid">
    <article class="ai-stat-card">
      <strong>OEM / ODM</strong>
      <p>Mô hình triển khai linh hoạt theo thiết kế của khách hàng hoặc đồng phát triển mẫu.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Đa thị trường</strong>
      <p>Tư duy vận hành theo tiêu chuẩn xuất khẩu và khác biệt yêu cầu từng khu vực.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Chuỗi khép kín</strong>
      <p>Kết nối nguyên liệu, sản xuất, QC và hậu cần để giảm rủi ro tiến độ.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Cải tiến liên tục</strong>
      <p>Ra quyết định dựa trên dữ liệu lỗi, lead time và phản hồi sau giao hàng.</p>
    </article>
  </div>

  <section id="company-intro" class="ai-section">
    <h2>Giới thiệu công ty</h2>
    <p>
      ANSLIFE tập trung vào sản xuất nội thất xuất khẩu với năng lực triển khai theo dự án,
      phù hợp cho cả đơn hàng chuẩn hóa và đơn hàng yêu cầu tùy biến theo thương hiệu.
    </p>
    <p>
      Điểm khác biệt của doanh nghiệp nằm ở việc phối hợp chặt giữa đội ngũ kinh doanh, kỹ thuật,
      phát triển mẫu và nhà máy, giúp rút ngắn vòng xác nhận kỹ thuật trước khi vào sản xuất đại trà.
    </p>
    <p>
      Trong giai đoạn V1, website được xây dựng nhằm trình bày rõ năng lực cốt lõi,
      tăng tốc quá trình tiếp cận thông tin cho đối tác và chuẩn bị nền tảng đa ngôn ngữ cho giai đoạn mở rộng.
    </p>
    <ul>
      <li>Tập trung phân khúc nội thất xuất khẩu có yêu cầu chất lượng đồng đều.</li>
      <li>Vận hành theo mô hình kiểm soát điểm chạm từ đầu vào đến trước xuất hàng.</li>
      <li>Ưu tiên minh bạch tiến độ và khả năng truy xuất theo từng lô sản xuất.</li>
    </ul>
    <div class="ai-highlight-grid">
      <article class="ai-highlight-card">
        <strong>Định vị</strong>
        <p>Đối tác sản xuất đáng tin cậy cho thương hiệu nội thất quốc tế.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Năng lực</strong>
        <p>Triển khai đồng thời nhiều line sản phẩm theo kế hoạch công suất.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Mục tiêu</strong>
        <p>Tăng trưởng bền vững dựa trên chất lượng, tốc độ và kỷ luật vận hành.</p>
      </article>
    </div>
  </section>

  <section id="vision-mission" class="ai-section">
    <h2>Tầm nhìn - Sứ mệnh</h2>
    <p>
      ANSLIFE theo đuổi định hướng trở thành đối tác sản xuất nội thất có năng lực đáp ứng ổn định
      cho các thị trường yêu cầu tiêu chuẩn cao, đồng thời giữ được tính linh hoạt theo từng dự án.
    </p>
    <ul>
      <li><strong>Tầm nhìn:</strong> Trở thành doanh nghiệp sản xuất nội thất Việt Nam có năng lực cạnh tranh dài hạn ở thị trường toàn cầu.</li>
      <li><strong>Sứ mệnh:</strong> Cung cấp giải pháp sản xuất minh bạch, tối ưu và nhất quán từ mẫu đến giao hàng.</li>
      <li><strong>Cam kết:</strong> Luôn đặt chất lượng thực tế và uy tín tiến độ là nền tảng hợp tác.</li>
    </ul>
    <p>
      Mỗi kế hoạch phát triển đều gắn với ba trụ cột: nâng chuẩn hệ thống sản xuất,
      phát triển đội ngũ và mở rộng quan hệ đối tác theo hướng lâu dài.
    </p>
  </section>

  <section id="core-values" class="ai-section">
    <h2>Giá trị cốt lõi</h2>
    <p>
      Giá trị cốt lõi không chỉ là tuyên bố thương hiệu mà được cụ thể hóa thành quy tắc vận hành,
      tiêu chí tuyển dụng và cách doanh nghiệp phản hồi trước vấn đề phát sinh.
    </p>
    <ul>
      <li><strong>Chính trực:</strong> Giao tiếp trung thực, báo cáo đúng thực trạng và chủ động đưa phương án xử lý.</li>
      <li><strong>Kỷ luật:</strong> Tuân thủ quy trình kỹ thuật và tiêu chuẩn kiểm soát đã thống nhất.</li>
      <li><strong>Hợp tác:</strong> Đồng hành cùng khách hàng, nhà cung ứng và đội ngũ nội bộ để đạt mục tiêu chung.</li>
      <li><strong>Cải tiến:</strong> Liên tục tối ưu dựa trên dữ liệu sản xuất và bài học sau mỗi dự án.</li>
    </ul>
    <p>
      Bộ giá trị này giúp ANSLIFE giữ ổn định chất lượng trong giai đoạn mở rộng quy mô và đa dạng thị trường.
    </p>
  </section>

  <section id="production-philosophy" class="ai-section">
    <h2>Triết lý sản xuất</h2>
    <p>
      Triết lý sản xuất của ANSLIFE được xây dựng quanh nguyên tắc: đúng thiết kế, đúng chất lượng,
      đúng tiến độ. Ba yếu tố này phải được đảm bảo đồng thời để tạo ra giá trị bền vững cho đối tác.
    </p>
    <div class="ai-highlight-grid">
      <article class="ai-highlight-card">
        <strong>Thiết kế khả thi</strong>
        <p>Ưu tiên khả năng sản xuất ổn định ngay từ giai đoạn phát triển mẫu.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Chất lượng có hệ thống</strong>
        <p>Kiểm soát sai lệch theo điểm chạm thay vì chỉ kiểm tra ở bước cuối.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Tiến độ có kỷ luật</strong>
        <p>Phối hợp kế hoạch vật tư, sản xuất và logistics theo mốc rõ ràng.</p>
      </article>
    </div>
    <p>
      Cách tiếp cận này giúp giảm lỗi lặp lại, giảm chi phí ẩn và tăng độ tin cậy khi chạy đơn hàng lớn.
    </p>
  </section>

  <section id="organization" class="ai-section">
    <h2>Cơ cấu tổ chức</h2>
    <p>
      Mô hình tổ chức của ANSLIFE được thiết kế theo hướng liên kết ngang,
      giúp thông tin kỹ thuật và vận hành không bị đứt đoạn giữa các phòng ban.
    </p>
    <ul>
      <li><strong>Kinh doanh:</strong> tiếp nhận yêu cầu, làm rõ phạm vi dự án và điều kiện thương mại.</li>
      <li><strong>R&D / Kỹ thuật:</strong> phân tích thiết kế, chuẩn hóa spec và phát triển mẫu.</li>
      <li><strong>Sản xuất:</strong> lập kế hoạch line, theo dõi công suất và kiểm soát tiến độ.</li>
      <li><strong>QC:</strong> giám sát chất lượng theo tiêu chí từng công đoạn.</li>
      <li><strong>Logistics:</strong> xử lý đóng gói, chứng từ và lịch vận chuyển quốc tế.</li>
    </ul>
    <p>
      Cơ cấu này tạo nền tảng phản hồi nhanh cho các dự án cần thay đổi cấu hình hoặc lịch giao gấp.
    </p>
  </section>

  <section id="team" class="ai-section">
    <h2>Đội ngũ</h2>
    <p>
      Đội ngũ ANSLIFE gồm các nhóm chuyên môn có kinh nghiệm xử lý đơn hàng xuất khẩu,
      đặc biệt ở các hạng mục yêu cầu cao về độ hoàn thiện bề mặt và độ chính xác kết cấu.
    </p>
    <p>
      Doanh nghiệp duy trì chương trình đào tạo nội bộ định kỳ cho kỹ năng kỹ thuật,
      quản trị chất lượng và phối hợp vận hành để tăng tính đồng bộ khi mở rộng quy mô.
    </p>
    <ul>
      <li>Đào tạo tiêu chuẩn công đoạn cho nhân sự mới và tổ trưởng line.</li>
      <li>Cập nhật kiến thức thị trường và yêu cầu kỹ thuật theo từng khách hàng.</li>
      <li>Đánh giá năng lực theo KPI chất lượng, tiến độ và khả năng xử lý vấn đề.</li>
    </ul>
  </section>

  <section id="anslife-ecosystem" class="ai-section">
    <h2>Hệ sinh thái ANSLIFE</h2>
    <p>
      Hệ sinh thái ANSLIFE được kết nối theo chuỗi để giảm điểm nghẽn giữa các bước,
      từ đó duy trì chất lượng ổn định khi sản lượng tăng.
    </p>
    <ol>
      <li><strong>Nguyên liệu:</strong> lựa chọn nhà cung cấp phù hợp tiêu chuẩn và khả năng truy xuất.</li>
      <li><strong>Sản xuất:</strong> tổ chức line linh hoạt theo nhóm sản phẩm.</li>
      <li><strong>QC:</strong> kiểm soát đa lớp và phản hồi nguyên nhân lỗi theo dữ liệu.</li>
      <li><strong>Thương mại:</strong> chuẩn hóa quy trình báo giá, xác nhận và vận hành đơn.</li>
      <li><strong>Logistics:</strong> đồng bộ đóng gói, chứng từ và lịch giao nhận quốc tế.</li>
    </ol>
    <p>
      Khi toàn bộ chuỗi vận hành theo cùng một ngôn ngữ dữ liệu,
      doanh nghiệp có thể ra quyết định nhanh hơn và giảm sai lệch giữa kế hoạch với thực tế.
    </p>
  </section>
</div>
`.trim(),"manufacturing-ecosystem":`
<div class="ai-content">
  <figure class="ai-banner">
    <img src="/assets/ai/manufacturing-ecosystem.svg" alt="Hệ sinh thái sản xuất" loading="lazy" decoding="async" />
  </figure>

  <p class="ai-intro">
    Hệ sinh thái sản xuất ANSLIFE được tổ chức theo mô hình mở rộng công suất có kiểm soát,
    kết hợp nhà máy lõi với nhà máy đối tác để tối ưu tiến độ, chất lượng và chi phí vận hành.
  </p>

  <div class="ai-stat-grid">
    <article class="ai-stat-card">
      <strong>Nhà máy lõi</strong>
      <p>Trung tâm chuẩn hóa kỹ thuật, quản trị chất lượng và vận hành mẫu.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Nhà máy đối tác</strong>
      <p>Năng lực bổ sung công suất theo mùa vụ và nhóm sản phẩm.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Chuỗi vật tư</strong>
      <p>Kiểm soát đầu vào theo lô và tiêu chí kỹ thuật cụ thể.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Đóng gói xuất khẩu</strong>
      <p>Tối ưu giải pháp bao gói để bảo vệ hàng trong toàn hành trình vận chuyển.</p>
    </article>
  </div>

  <section id="production-system" class="ai-section">
    <h2>Hệ thống sản xuất</h2>
    <p>
      Hệ thống sản xuất được xây dựng theo cách phân tầng năng lực, trong đó nhà máy ANSLIFE đóng vai trò
      kiểm soát tiêu chuẩn và nhà máy đối tác đảm nhiệm mở rộng công suất theo kế hoạch đã chuẩn hóa.
    </p>
    <ul>
      <li><strong>Nhà máy ANSLIFE:</strong> kiểm soát kỹ thuật lõi, quy trình QC và các mã hàng yêu cầu độ chính xác cao.</li>
      <li><strong>Nhà máy đối tác:</strong> triển khai các line sản phẩm đã được chuẩn hóa quy cách sản xuất.</li>
      <li><strong>Điều phối công suất:</strong> phân bổ sản lượng theo năng lực, lead time và lịch giao thực tế.</li>
    </ul>
    <p>
      Cách tổ chức này giúp doanh nghiệp giữ ổn định chất lượng khi mở rộng sản lượng,
      đồng thời giảm rủi ro phụ thuộc vào một điểm sản xuất duy nhất.
    </p>
  </section>

  <section id="raw-material-zone" class="ai-section">
    <h2>Vùng nguyên liệu</h2>
    <p>
      Nguồn nguyên liệu được đánh giá theo bốn tiêu chí: ổn định nguồn cung,
      phù hợp yêu cầu kỹ thuật, khả năng truy xuất và hiệu quả chi phí dài hạn.
    </p>
    <p>
      Mỗi lô nguyên liệu quan trọng đều đi qua quy trình kiểm tra đầu vào trước khi cấp phát cho line sản xuất,
      giúp giảm sai lệch phát sinh ở các công đoạn sau.
    </p>
    <ul>
      <li>Đánh giá định kỳ nhà cung ứng và hiệu suất giao hàng.</li>
      <li>Kiểm tra độ ẩm, bề mặt, quy cách kích thước theo checklist.</li>
      <li>Lưu mẫu và hồ sơ lô phục vụ truy xuất khi có yêu cầu.</li>
    </ul>
  </section>

  <section id="manufacturing-process" class="ai-section">
    <h2>Quy trình sản xuất</h2>
    <p>
      Quy trình sản xuất được chuẩn hóa theo từng giai đoạn để dễ kiểm soát chất lượng,
      đồng thời đảm bảo thông tin truyền đạt nhất quán giữa kỹ thuật, sản xuất và QC.
    </p>
    <div class="ai-highlight-grid">
      <article class="ai-highlight-card">
        <strong>Phát triển mẫu</strong>
        <p>Đánh giá tính khả thi, cấu trúc và mức độ sẵn sàng cho sản xuất hàng loạt.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Gia công</strong>
        <p>Kiểm soát sai số công đoạn cắt, khoan, tạo hình theo chuẩn kỹ thuật.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Lắp ráp</strong>
        <p>Kiểm tra độ khớp, độ chắc và độ ổn định kết cấu.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Sơn hoàn thiện</strong>
        <p>Đồng nhất màu sắc, độ phủ và độ bền bề mặt theo mẫu duyệt.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Đóng gói</strong>
        <p>Thiết kế cấu trúc bao gói phù hợp tuyến vận chuyển và yêu cầu khách hàng.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Bàn giao logistics</strong>
        <p>Đối chiếu nhãn, số lượng và chứng từ trước khi xuất hàng.</p>
      </article>
    </div>
  </section>

  <section id="standards-certificates" class="ai-section">
    <h2>Tiêu chuẩn & chứng chỉ</h2>
    <p>
      ANSLIFE duy trì bộ tiêu chuẩn nội bộ theo từng công đoạn và cập nhật liên tục theo yêu cầu thị trường,
      quy định nhập khẩu cũng như bộ tiêu chí của từng đối tác.
    </p>
    <ul>
      <li>Chuẩn kỹ thuật đầu vào nguyên liệu và vật tư phụ trợ.</li>
      <li>Chuẩn kiểm soát sai số và mức chấp nhận trong sản xuất.</li>
      <li>Chuẩn nghiệm thu trước xuất hàng và hồ sơ bàn giao.</li>
    </ul>
    <p>
      Việc chuẩn hóa ngay từ đầu giúp quá trình mở rộng đa nhà máy vẫn giữ được ngưỡng chất lượng đồng nhất.
    </p>
  </section>
</div>
`.trim(),"quality-control":`
<div class="ai-content">
  <figure class="ai-banner">
    <img src="/assets/ai/quality-control.svg" alt="Kiểm soát chất lượng" loading="lazy" decoding="async" />
  </figure>

  <p class="ai-intro">
    Hệ thống QC của ANSLIFE vận hành theo nguyên tắc phòng ngừa trước, phát hiện sớm và khắc phục ngay,
    giúp giảm tỷ lệ lỗi lặp lại và tăng độ ổn định chất lượng cho đơn hàng xuất khẩu.
  </p>

  <div class="ai-stat-grid">
    <article class="ai-stat-card">
      <strong>Input QC</strong>
      <p>Kiểm soát nguyên liệu trước khi vào sản xuất để chặn lỗi từ gốc.</p>
    </article>
    <article class="ai-stat-card">
      <strong>In-line QC</strong>
      <p>Giám sát điểm chạm trọng yếu trong từng công đoạn.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Pre-shipment</strong>
      <p>Đánh giá tổng thể theo tiêu chí nghiệm thu trước xuất hàng.</p>
    </article>
    <article class="ai-stat-card">
      <strong>CAPA</strong>
      <p>Phân tích nguyên nhân gốc và hành động khắc phục phòng ngừa.</p>
    </article>
  </div>

  <section id="qc-philosophy" class="ai-section">
    <h2>Triết lý QC</h2>
    <p>
      Chất lượng không được xem là nhiệm vụ của một bộ phận riêng lẻ,
      mà là trách nhiệm xuyên suốt từ thiết kế, nguyên liệu, sản xuất đến đóng gói.
    </p>
    <p>
      ANSLIFE ưu tiên hệ thống kiểm soát theo quá trình để giảm lỗi ngay từ đầu,
      thay vì phụ thuộc vào khâu kiểm cuối cùng.
    </p>
    <ul>
      <li>Kiểm soát phòng ngừa trước khi lỗi xảy ra.</li>
      <li>Phản hồi nhanh theo dữ liệu tại hiện trường.</li>
      <li>Chuẩn hóa bài học để tránh lỗi lặp lại.</li>
    </ul>
  </section>

  <section id="qc-system" class="ai-section">
    <h2>Hệ thống QC</h2>
    <p>
      Hệ thống QC được thiết kế với các checkpoint rõ ràng theo từng công đoạn,
      kèm biểu mẫu ghi nhận tiêu chí, sai lệch và phương án xử lý.
    </p>
    <div class="ai-highlight-grid">
      <article class="ai-highlight-card">
        <strong>Tiêu chí kiểm</strong>
        <p>Xây dựng theo bản vẽ kỹ thuật, mẫu duyệt và yêu cầu thị trường.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Báo cáo lỗi</strong>
        <p>Ghi nhận mã lỗi và nguyên nhân để xử lý tận gốc.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Phản hồi liên phòng ban</strong>
        <p>QC, kỹ thuật và sản xuất phối hợp đóng lỗi trong cùng chu kỳ vận hành.</p>
      </article>
    </div>
    <p>
      Khi dữ liệu lỗi được chuẩn hóa, doanh nghiệp có thể đánh giá xu hướng và ưu tiên đúng điểm cải tiến.
    </p>
  </section>

  <section id="input-inspection" class="ai-section">
    <h2>Kiểm tra nguyên liệu</h2>
    <p>
      Ở bước đầu vào, QC tập trung kiểm tra độ phù hợp của nguyên liệu với tiêu chí kỹ thuật,
      đặc biệt ở các yếu tố ảnh hưởng trực tiếp đến độ bền và bề mặt hoàn thiện.
    </p>
    <ul>
      <li>Kiểm tra độ ẩm, vân gỗ, màu sắc và sai số kích thước.</li>
      <li>Đối chiếu chứng từ lô hàng và thông tin truy xuất.</li>
      <li>Phân loại theo mức độ phù hợp trước khi cấp phát line.</li>
    </ul>
    <p>
      Bước này giúp giảm đáng kể nguy cơ lỗi truyền qua các công đoạn gia công và sơn hoàn thiện.
    </p>
  </section>

  <section id="in-process-inspection" class="ai-section">
    <h2>Kiểm tra trong sản xuất</h2>
    <p>
      QC in-line được thực hiện tại các điểm chạm quan trọng để phát hiện sớm sai lệch,
      tránh việc phải xử lý hàng loạt ở giai đoạn sau.
    </p>
    <ul>
      <li>Kiểm tra kích thước, độ vuông góc, độ khớp kết cấu ở công đoạn gia công và lắp ráp.</li>
      <li>Kiểm tra bề mặt, màu sắc, độ phủ sau công đoạn sơn.</li>
      <li>Theo dõi tỷ lệ lỗi theo line để điều chỉnh ngay trong ca sản xuất.</li>
    </ul>
  </section>

  <section id="pre-shipment-inspection" class="ai-section">
    <h2>Kiểm tra trước xuất hàng</h2>
    <p>
      Trước khi bàn giao logistics, lô hàng được kiểm tổng thể theo tiêu chí nghiệm thu đã thống nhất với khách hàng,
      gồm chất lượng sản phẩm, số lượng, bao gói và thông tin nhãn mác.
    </p>
    <ul>
      <li>Đánh giá ngoại quan, kết cấu, chức năng sử dụng.</li>
      <li>Đối chiếu carton, nhãn, manual và packing list.</li>
      <li>Áp dụng phương pháp lấy mẫu theo mức AQL phù hợp.</li>
    </ul>
    <p>
      Kết quả kiểm trước xuất hàng là căn cứ quan trọng để đảm bảo độ tin cậy khi giao hàng quốc tế.
    </p>
  </section>

  <section id="quality-improvement-cases" class="ai-section">
    <h2>Case cải tiến chất lượng</h2>
    <p>
      ANSLIFE lưu trữ và chuẩn hóa các case cải tiến chất lượng nhằm rút ngắn thời gian xử lý,
      đồng thời chuyển bài học vận hành thành quy trình phòng ngừa có thể tái sử dụng.
    </p>
    <div class="ai-highlight-grid">
      <article class="ai-highlight-card">
        <strong>Case 01</strong>
        <p>Tối ưu trình tự lắp ráp giúp giảm tỷ lệ lệch khớp ở sản phẩm dạng module.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Case 02</strong>
        <p>Điều chỉnh thông số sơn để tăng độ ổn định màu giữa các lô sản xuất.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Case 03</strong>
        <p>Chuẩn hóa kết cấu bao gói để giảm tỷ lệ hư hại trong vận chuyển xa.</p>
      </article>
    </div>
  </section>
</div>
`.trim(),"commercial-process":`
<div class="ai-content">
  <figure class="ai-banner">
    <img src="/assets/ai/commercial-process.svg" alt="Quy trình thương mại" loading="lazy" decoding="async" />
  </figure>

  <p class="ai-intro">
    Quy trình thương mại được thiết kế rõ ràng theo từng mốc để khách hàng theo dõi tiến độ,
    chủ động kế hoạch nhập hàng và kiểm soát rủi ro trong suốt vòng đời đơn hàng.
  </p>

  <div class="ai-stat-grid">
    <article class="ai-stat-card">
      <strong>RFQ rõ ràng</strong>
      <p>Làm rõ yêu cầu kỹ thuật và phạm vi cung ứng trước khi báo giá.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Điều khoản minh bạch</strong>
      <p>Thống nhất trách nhiệm và thời điểm bàn giao theo Incoterms.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Tiến độ theo mốc</strong>
      <p>Cập nhật trạng thái từ mẫu, sản xuất, QC đến xuất hàng.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Hỗ trợ sau giao</strong>
      <p>Duy trì phối hợp chứng từ và phản hồi kỹ thuật khi cần thiết.</p>
    </article>
  </div>

  <section id="order-flow" class="ai-section">
    <h2>Quy trình đặt hàng</h2>
    <p>
      Quy trình được chuẩn hóa theo từng bước để giảm sai lệch thông tin và rút ngắn thời gian xác nhận đơn.
    </p>
    <ol>
      <li>Tiếp nhận yêu cầu và làm rõ thông số kỹ thuật.</li>
      <li>Phân tích vật liệu, cấu hình hoàn thiện và điều kiện đóng gói.</li>
      <li>Báo giá và xác nhận điều kiện thương mại.</li>
      <li>Đối chiếu mẫu hoặc tài liệu kỹ thuật trước khi chốt đơn.</li>
      <li>Lập kế hoạch sản xuất và lịch giao dự kiến.</li>
      <li>Cập nhật tiến độ theo mốc đã cam kết.</li>
      <li>Chốt kiểm trước xuất và bàn giao logistics.</li>
    </ol>
    <p>
      Cấu trúc quy trình này giúp cả hai bên chủ động quản trị kỳ vọng và giảm phát sinh khi dự án đi vào triển khai.
    </p>
  </section>

  <section id="incoterms" class="ai-section">
    <h2>Điều kiện giao hàng (Incoterms)</h2>
    <p>
      ANSLIFE hỗ trợ linh hoạt các điều kiện giao hàng phổ biến như EXW, FOB, CIF,
      tùy theo năng lực logistics và chiến lược mua hàng của đối tác.
    </p>
    <ul>
      <li>Thống nhất điểm chuyển giao trách nhiệm và rủi ro ngay từ đầu.</li>
      <li>Đồng bộ yêu cầu chứng từ theo điều kiện giao nhận đã chọn.</li>
      <li>Rà soát lịch vận chuyển để phù hợp thời gian sản xuất thực tế.</li>
    </ul>
  </section>

  <section id="payment" class="ai-section">
    <h2>Phương thức thanh toán</h2>
    <p>
      Điều khoản thanh toán được xây dựng theo mức độ rủi ro dự án, quy mô đơn hàng và lịch giao,
      đảm bảo minh bạch cho cả hai bên trong suốt quá trình thực hiện.
    </p>
    <ul>
      <li>Xác định mốc thanh toán theo tiến độ triển khai.</li>
      <li>Đảm bảo hồ sơ đối soát rõ ràng theo từng lô xuất.</li>
      <li>Phối hợp nhanh khi cần điều chỉnh phương án tài chính.</li>
    </ul>
  </section>

  <section id="lead-time" class="ai-section">
    <h2>Thời gian sản xuất</h2>
    <p>
      Lead time được tính toán dựa trên quy mô đơn hàng, độ phức tạp thiết kế,
      năng lực line hiện tại và lịch cung ứng nguyên vật liệu.
    </p>
    <p>
      Trong quá trình sản xuất, khách hàng được cập nhật theo từng mốc chính,
      từ chuẩn bị vật tư, chạy line, QC đến hoàn thiện đóng gói.
    </p>
    <div class="ai-highlight-grid">
      <article class="ai-highlight-card">
        <strong>Mốc 1</strong>
        <p>Chuẩn bị vật tư và xác nhận năng lực line.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Mốc 2</strong>
        <p>Triển khai sản xuất, kiểm soát in-line và xử lý sai lệch.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Mốc 3</strong>
        <p>Kiểm trước xuất, đóng gói và bàn giao logistics.</p>
      </article>
    </div>
  </section>

  <section id="logistics" class="ai-section">
    <h2>Logistics</h2>
    <p>
      Đội ngũ thương mại và logistics phối hợp chặt để kiểm soát lịch tàu,
      chứng từ xuất khẩu và phương án bao gói phù hợp từng tuyến vận chuyển.
    </p>
    <ul>
      <li>Chuẩn hóa đóng gói theo loại sản phẩm và thời gian hành trình.</li>
      <li>Đảm bảo chứng từ đầy đủ, giảm rủi ro chậm thông quan.</li>
      <li>Cập nhật minh bạch trạng thái giao nhận cho đối tác.</li>
    </ul>
  </section>
</div>
`.trim(),"global-network":`
<div class="ai-content">
  <figure class="ai-banner">
    <img src="/assets/ai/global-network.svg" alt="Hệ thống toàn cầu" loading="lazy" decoding="async" />
  </figure>

  <p class="ai-intro">
    Hệ thống toàn cầu ANSLIFE kết nối trung tâm sản xuất tại Việt Nam với mạng lưới thị trường,
    giúp luồng thông tin giữa khách hàng, đội ngũ thương mại và vận hành luôn xuyên suốt.
  </p>

  <div class="ai-stat-grid">
    <article class="ai-stat-card">
      <strong>Việt Nam</strong>
      <p>Trung tâm điều phối sản xuất, kỹ thuật và QC.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Singapore</strong>
      <p>Điểm kết nối thương mại khu vực ASEAN.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Nhật Bản</strong>
      <p>Hỗ trợ thị trường yêu cầu chất lượng khắt khe.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Hoa Kỳ</strong>
      <p>Phối hợp dự án và phản hồi nhanh theo múi giờ địa phương.</p>
    </article>
  </div>

  <section id="vietnam-hq" class="ai-section">
    <h2>Việt Nam - Trụ sở</h2>
    <p>
      Trụ sở Việt Nam là điểm điều phối trung tâm cho các hoạt động kinh doanh, kỹ thuật,
      sản xuất, QC và logistics của toàn hệ thống.
    </p>
    <p>
      Tại đây, các quyết định về năng lực công suất, chuẩn kỹ thuật và tiến độ dự án
      được thống nhất để đảm bảo mức độ đồng bộ cao khi triển khai đơn hàng quốc tế.
    </p>
    <ul>
      <li>Điều phối kế hoạch sản xuất và nguồn lực liên phòng ban.</li>
      <li>Quản trị dữ liệu dự án và tiêu chí chất lượng chuẩn.</li>
      <li>Hỗ trợ khách hàng trong toàn bộ vòng đời đơn hàng.</li>
    </ul>
  </section>

  <section id="singapore-office" class="ai-section">
    <h2>Singapore - Văn phòng đại diện</h2>
    <p>
      Văn phòng Singapore đóng vai trò cầu nối thương mại khu vực,
      hỗ trợ liên lạc với đối tác ASEAN và tăng tốc xử lý nhu cầu dự án xuyên quốc gia.
    </p>
    <p>
      Nhờ vị trí thuận lợi về logistics và tài chính,
      điểm kết nối này giúp doanh nghiệp nâng tính linh hoạt trong điều phối giao thương.
    </p>
  </section>

  <section id="japan-office" class="ai-section">
    <h2>Nhật Bản - Văn phòng đại diện</h2>
    <p>
      Văn phòng Nhật Bản tập trung hỗ trợ thị trường có tiêu chuẩn cao về chi tiết kỹ thuật,
      độ hoàn thiện và tính ổn định chất lượng giữa các lô hàng.
    </p>
    <ul>
      <li>Hỗ trợ truyền đạt yêu cầu kỹ thuật đặc thù của thị trường Nhật.</li>
      <li>Rút ngắn thời gian phản hồi nhờ kênh làm việc trực tiếp.</li>
      <li>Đồng hành cùng khách hàng trong các giai đoạn nghiệm thu.</li>
    </ul>
  </section>

  <section id="us-office" class="ai-section">
    <h2>Hoa Kỳ - Văn phòng đại diện</h2>
    <p>
      Kênh đại diện tại Hoa Kỳ giúp ANSLIFE tăng tốc phản hồi cho đối tác Bắc Mỹ,
      đặc biệt ở các dự án cần cập nhật thường xuyên theo múi giờ địa phương.
    </p>
    <p>
      Đây cũng là điểm kết nối hỗ trợ thông tin hậu cần, tài liệu dự án
      và điều phối trao đổi sau giao hàng khi cần.
    </p>
  </section>

  <section id="international-partners" class="ai-section">
    <h2>Đối tác quốc tế</h2>
    <p>
      Hệ đối tác quốc tế của ANSLIFE được phát triển theo nguyên tắc dài hạn:
      minh bạch, tin cậy và đồng cải tiến năng lực triển khai dự án.
    </p>
    <div class="ai-highlight-grid">
      <article class="ai-highlight-card">
        <strong>Đối tác thương mại</strong>
        <p>Hợp tác mở rộng thị trường và chuẩn hóa quy trình làm việc.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Đối tác sản xuất</strong>
        <p>Bổ sung công suất theo chuẩn kỹ thuật đã được đồng bộ.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Đối tác logistics</strong>
        <p>Tối ưu tuyến vận chuyển và độ tin cậy thời gian giao nhận.</p>
      </article>
    </div>
  </section>
</div>
`.trim(),"scholarship-community":`
<div class="ai-content">
  <figure class="ai-banner">
    <img src="/assets/ai/scholarship-community.svg" alt="Quỹ học bổng và cộng đồng" loading="lazy" decoding="async" />
  </figure>

  <p class="ai-intro">
    Bên cạnh hoạt động sản xuất, ANSLIFE xây dựng quỹ học bổng và chương trình cộng đồng
    như một phần cam kết phát triển bền vững cùng địa phương và thế hệ trẻ.
  </p>

  <div class="ai-stat-grid">
    <article class="ai-stat-card">
      <strong>Giáo dục</strong>
      <p>Ưu tiên hỗ trợ học sinh, sinh viên có tinh thần vượt khó.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Cộng đồng</strong>
      <p>Đồng hành cùng chương trình xã hội thiết thực tại địa phương.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Minh bạch</strong>
      <p>Vận hành quỹ theo mục tiêu, tiêu chí và báo cáo rõ ràng.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Kết nối dài hạn</strong>
      <p>Tạo mạng lưới đồng hành giữa doanh nghiệp, tổ chức và cá nhân.</p>
    </article>
  </div>

  <section id="fund-overview" class="ai-section">
    <h2>Giới thiệu quỹ</h2>
    <p>
      Quỹ học bổng ANSLIFE hướng đến việc mở rộng cơ hội học tập cho học sinh, sinh viên,
      đặc biệt là các trường hợp có nỗ lực vươn lên trong điều kiện khó khăn.
    </p>
    <p>
      Quỹ được vận hành theo nguyên tắc tập trung đúng đối tượng,
      triển khai đều đặn theo chu kỳ và đánh giá hiệu quả dựa trên kết quả thực tế.
    </p>
    <ul>
      <li>Ưu tiên hỗ trợ đúng nhu cầu thiết thực của người học.</li>
      <li>Kết hợp học bổng tài chính với hoạt động định hướng nghề nghiệp.</li>
      <li>Tăng tính bền vững thông qua mạng lưới đồng hành xã hội.</li>
    </ul>
  </section>

  <section id="scholarship-program" class="ai-section">
    <h2>Chương trình học bổng</h2>
    <p>
      Chương trình học bổng được xây dựng theo từng giai đoạn,
      trong đó mỗi kỳ sẽ có mục tiêu rõ ràng về số lượng, phạm vi và tiêu chí xét chọn.
    </p>
    <ul>
      <li><strong>Mục tiêu:</strong> khuyến khích nỗ lực học tập và phát triển kỹ năng dài hạn.</li>
      <li><strong>Điều kiện:</strong> xét theo hoàn cảnh, thành tích và thái độ học tập.</li>
      <li><strong>Đồng hành:</strong> kết nối mentor, doanh nghiệp và người nhận học bổng.</li>
      <li><strong>Câu chuyện học bổng:</strong> ghi nhận hành trình vượt khó để lan tỏa cảm hứng tích cực.</li>
    </ul>
  </section>

  <section id="community-activities" class="ai-section">
    <h2>Hoạt động cộng đồng</h2>
    <p>
      Các hoạt động cộng đồng tập trung vào nhóm chương trình mang lại giá trị trực tiếp,
      như hỗ trợ giáo dục, cải thiện điều kiện học tập và các hoạt động xã hội tại địa phương.
    </p>
    <div class="ai-highlight-grid">
      <article class="ai-highlight-card">
        <strong>Dự án giáo dục</strong>
        <p>Hỗ trợ học cụ, thư viện nhỏ và các không gian học tập cơ bản.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Hoạt động xã hội</strong>
        <p>Phối hợp các chương trình thiện nguyện theo từng giai đoạn.</p>
      </article>
      <article class="ai-highlight-card">
        <strong>Phát triển địa phương</strong>
        <p>Khuyến khích nhân sự nội bộ tham gia đóng góp cộng đồng.</p>
      </article>
    </div>
  </section>

  <section id="join-anslife" class="ai-section">
    <h2>Tham gia cùng ANSLIFE</h2>
    <p>
      Doanh nghiệp, tổ chức và cá nhân có thể đồng hành cùng ANSLIFE thông qua nhiều hình thức,
      từ tài trợ nguồn lực, phối hợp chương trình đến chia sẻ chuyên môn.
    </p>
    <ol>
      <li>Đăng ký mối quan tâm và phạm vi hỗ trợ.</li>
      <li>Thống nhất chương trình phù hợp với năng lực đóng góp.</li>
      <li>Triển khai và theo dõi kết quả theo từng giai đoạn.</li>
      <li>Tổng kết, đánh giá và mở rộng các chương trình hiệu quả.</li>
    </ol>
    <p>
      Cách làm này giúp mỗi hoạt động cộng đồng đi vào thực chất,
      tạo tác động rõ ràng thay vì chỉ dừng ở các chiến dịch ngắn hạn.
    </p>
  </section>
</div>
`.trim(),contact:`
<div class="ai-content ai-contact-content">
  <figure class="ai-banner">
    <img src="/assets/ai/contact.svg" alt="Liên hệ ANSLIFE" loading="lazy" decoding="async" />
  </figure>

  <p class="ai-intro">
    Đội ngũ ANSLIFE sẵn sàng tiếp nhận yêu cầu báo giá, hỗ trợ kỹ thuật sản phẩm,
    đặt lịch làm việc và trao đổi kế hoạch hợp tác theo từng thị trường.
  </p>

  <div class="ai-stat-grid">
    <article class="ai-stat-card">
      <strong>Phản hồi nhanh</strong>
      <p>Ưu tiên phản hồi thông tin trong khung thời gian làm việc gần nhất.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Hỗ trợ kỹ thuật</strong>
      <p>Tư vấn theo mã hàng, vật liệu, cấu trúc và tiêu chuẩn hoàn thiện.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Hỗ trợ thương mại</strong>
      <p>Đồng bộ báo giá, điều kiện giao hàng và quy trình đơn hàng.</p>
    </article>
    <article class="ai-stat-card">
      <strong>Làm việc đa kênh</strong>
      <p>Hỗ trợ email, điện thoại và lịch hẹn trực tiếp.</p>
    </article>
  </div>

  <div class="ai-contact-grid">
    <article class="ai-highlight-card">
      <h3>Trụ sở chính</h3>
      <p>26 Từ Đình, Long Biên, Hà Nội</p>
      <p>Email: sales@anslife.vn</p>
      <p>Hotline: (+84) 983 150 336</p>
      <p>Giờ làm việc: Thứ 2 - Thứ 7, 08:00 - 17:30</p>
    </article>

    <article class="ai-highlight-card">
      <h3>Văn phòng TP. HCM</h3>
      <p>23 Hoàng Kế Viêm, P.14, Q.Tân Bình</p>
      <p>Hỗ trợ gặp trực tiếp theo lịch hẹn.</p>
      <p>Phù hợp cho trao đổi dự án và xác nhận mẫu.</p>
    </article>

    <article class="ai-highlight-card">
      <h3>Nhà máy</h3>
      <p>KCN Hố Nai 3, Đồng Nai, Việt Nam</p>
      <p>Đón tiếp tham quan nhà máy theo đăng ký trước.</p>
      <p>Hỗ trợ khảo sát năng lực sản xuất theo từng nhóm sản phẩm.</p>
    </article>
  </div>

  <section class="ai-section">
    <h2>Hướng dẫn gửi yêu cầu nhanh</h2>
    <p>
      Để nhận phản hồi chính xác và nhanh hơn, bạn nên cung cấp rõ nhóm sản phẩm,
      thị trường mục tiêu, số lượng dự kiến và yêu cầu chất lượng ưu tiên.
    </p>
    <ul>
      <li>Đính kèm bản vẽ hoặc ảnh tham chiếu nếu đã có.</li>
      <li>Nêu rõ thời gian mong muốn nhận báo giá / triển khai.</li>
      <li>Cho biết điều kiện giao hàng dự kiến để tư vấn phù hợp.</li>
    </ul>
  </section>
</div>
`.trim()};function o(n){return h[n]??null}function r(n){return n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function u(n,c){const t=h[n];if(!t)return null;const g=r(c),a=new RegExp(`<section\\s+id="${g}"[^>]*>[\\s\\S]*?<\\/section>`,"i"),i=t.match(a);if(!i)return null;const s=t.match(/<figure class="ai-banner">[\s\S]*?<\/figure>/i),l=t.match(/<p class="ai-intro">[\s\S]*?<\/p>/i);return`
<div class="ai-content">
  ${s?.[0]??""}
  ${l?.[0]??""}
  ${i[0]}
</div>
`.trim()}export{u as a,o as g};
